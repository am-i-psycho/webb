import express from "express";

const app = express();

const PORT = 50000;

app.use(express.json());
app.disable("etag");

function imageGen(img, msg) {
  return `<style>body{display: flex;flex-direction: column;align-items: center;justify-content: center;text-align: center;}</style><div class="container"><h1>${msg}</h1><img src=${img} /></div>`;
}

app.get("/", (req, res) => {
  /// browser
  const ourBrowser = "cid-browser";
  const browserErrorMsg = "you are not using cid-browser";
  const browserErrorImg =
    "https://media1.tenor.com/m/rxWUNq9P6owAAAAd/jagathy-lsdgifzz.gif";
  const browserHeader = req.headers["user-agent"] || req.headers["User-Agent"];
  if (!browserHeader || !browserHeader.toLowerCase().includes(ourBrowser)) {
    return res.send(imageGen(browserErrorImg, browserErrorMsg));
  }
  // date

  const ourDate = new Date("Wed, 21 Oct 2018");
  const dateErrorMsg = "This page only worked on 21 Oct 2018";
  const dateErrorImg =
    "https://media1.tenor.com/m/rxWUNq9P6owAAAAd/jagathy-lsdgifzz.gif";
  const dateHeader = req.headers["date"] || req.headers["Date"];
  let userProvidedDate;
  if (dateHeader) {
    userProvidedDate = new Date(dateHeader);
  }

  if (!dateHeader || userProvidedDate.getTime() !== ourDate.getTime()) {
    res.send(imageGen(dateErrorImg, dateErrorMsg));
  }
  // do not track
  const trackHeader = req.headers["DNT"] || req.headers["dnt"];
  const dntErrorMsg = "some one is tracking you";
  const dntErrorImg =
    "https://media1.tenor.com/m/rxWUNq9P6owAAAAd/jagathy-lsdgifzz.gif";
  if (!trackHeader || trackHeader != 1) {
    return res.send(imageGen(dntErrorImg, dntErrorMsg));
  }

  // referer
  const refererErrorMsg = "not correct referer";
  const refererErrorImg =
    "https://media1.tenor.com/m/rxWUNq9P6owAAAAd/jagathy-lsdgifzz.gif";
  const ourReferer = "89.116.122.219";
  const refererHeader = req.headers["referer"] || req.headers["referrer"];
  if (!refererHeader || !refererHeader.toLowerCase().includes(ourReferer)) {
    return res.send(imageGen(refererErrorImg, refererErrorMsg));
  }

  // accept language
  const languageErrorImg =
    "https://media1.tenor.com/m/rxWUNq9P6owAAAAd/jagathy-lsdgifzz.gif";
  const languageErrorMsg = "not correct language";
  const acceptLanguageHeader =
    req.headers["accept-language"] || req.headers["Accept-Language"];
  const ourLanguage = "ml; q=0.8";
;
  if (
    !acceptLanguageHeader ||
    !acceptLanguageHeader.toLowerCase().includes(ourLanguage)
  ) {
    return res.send(imageGen(languageErrorImg, languageErrorMsg));
  }

  /// flag
  const flagMsg =
    "this is your flag CID{ee_4anDil_enGanUm_S3ri_Av0do_}";
  const flagImg =
    "https://m.media-amazon.com/images/M/MV5BZjkzYmZmNTctZWIzZS00NTUxLTgwMWEtNzdmOTRjZjQ3OWFhXkEyXkFqcGdeQXVyNjIwMTk0NTY@._V1_.jpg";
  return res.send(imageGen(flagImg, flagMsg));
});

// function inserImage (imgLink){

//   return ``
// }

app.listen(PORT, () => {
  console.log(`server started ${PORT}`);
});
